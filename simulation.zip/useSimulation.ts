// ─────────────────────────────────────────────────────────────────────────────
// useSimulation.ts
// React hook — connects mm1Service logic to UI state.
// Place this in: frontend/src/hooks/useSimulation.ts
// ─────────────────────────────────────────────────────────────────────────────

import { useState } from "react";
import {
  simulateMM1,
  validateInput,
  type SimResults,
  type ValidationError,
} from "@/services/mm1Service";

// ─── Hook Return Type ─────────────────────────────────────────────────────────

export type UseSimulationReturn = {
  // form state
  lambda: string;
  mu: string;
  customers: string;
  setLambda: (v: string) => void;
  setMu: (v: string) => void;
  setCustomers: (v: string) => void;

  // results & error
  results: SimResults | null;
  error: ValidationError | null;

  // actions
  run: () => void;
  reset: () => void;
};

// ─── Hook ─────────────────────────────────────────────────────────────────────

export function useSimulation(): UseSimulationReturn {
  const [lambda,    setLambda]    = useState("0.5");
  const [mu,        setMu]        = useState("0.8");
  const [customers, setCustomers] = useState("8");

  const [results, setResults] = useState<SimResults | null>(null);
  const [error,   setError]   = useState<ValidationError | null>(null);

  function run() {
    setError(null);

    const input = {
      lambda:    parseFloat(lambda),
      mu:        parseFloat(mu),
      n:         parseInt(customers),
    };

    // Validate first
    const validationError = validateInput(input);
    if (validationError) {
      setError(validationError);
      return;
    }

    // Run simulation
    const simResults = simulateMM1(input);
    setResults(simResults);
  }

  function reset() {
    setResults(null);
    setError(null);
    setLambda("0.5");
    setMu("0.8");
    setCustomers("8");
  }

  return {
    lambda,
    mu,
    customers,
    setLambda,
    setMu,
    setCustomers,
    results,
    error,
    run,
    reset,
  };
}
