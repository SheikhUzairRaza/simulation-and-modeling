// ─────────────────────────────────────────────────────────────────────────────
// mm1Service.ts
// Pure M/M/1 simulation logic — no React, no UI, just math.
// Place this in: frontend/src/services/mm1Service.ts
// ─────────────────────────────────────────────────────────────────────────────

// ─── Types ───────────────────────────────────────────────────────────────────

export type CustomerRow = {
  id: number;
  interArrival: number;   // gap from previous arrival
  arrivalTime: number;    // when customer arrives
  serviceTime: number;    // how long serving takes
  startTime: number;      // when server starts serving
  endTime: number;        // when customer leaves server
  waitTime: number;       // time spent waiting in queue
  turnaroundTime: number; // total time in system (wait + service)
  responseTime: number;   // time from start to end (= service time)
};

export type SimResults = {
  customers: CustomerRow[];
  avgInterArrival: number;
  avgWait: number;
  avgService: number;
  avgTurnaround: number;
  avgResponse: number;
  utilization: number;    // percentage 0-100
  totalTime: number;
};

export type SimInput = {
  lambda: number;   // arrival rate (customers per minute)
  mu: number;       // service rate (customers per minute)
  n: number;        // number of customers to simulate
};

export type ValidationError = {
  field: "lambda" | "mu" | "n" | "stability";
  message: string;
};

// ─── Validation ───────────────────────────────────────────────────────────────

export function validateInput(input: SimInput): ValidationError | null {
  const { lambda, mu, n } = input;

  if (isNaN(lambda) || lambda <= 0)
    return { field: "lambda", message: "Lambda must be a positive number." };

  if (isNaN(mu) || mu <= 0)
    return { field: "mu", message: "Mu must be a positive number." };

  if (isNaN(n) || n < 2 || n > 30)
    return { field: "n", message: "Customers must be between 2 and 30." };

  if (lambda >= mu)
    return { field: "stability", message: "Lambda must be less than Mu for a stable queue (ρ < 1)." };

  return null;
}

// ─── Core Math ────────────────────────────────────────────────────────────────

/**
 * Generate an exponentially distributed random variate.
 * Uses inverse transform method: X = -(1/rate) * ln(U)
 * where U is uniform(0,1).
 */
function expRandom(rate: number): number {
  const u = Math.max(Math.random(), 1e-10); // avoid ln(0)
  return (-1 / rate) * Math.log(u);
}

/** Round to 2 decimal places */
function round2(n: number): number {
  return Math.round(n * 100) / 100;
}

// ─── Simulation Runner ────────────────────────────────────────────────────────

/**
 * Run a full M/M/1 queue simulation.
 *
 * Steps per customer:
 *  1. Generate inter-arrival time using expRandom(lambda)
 *  2. Arrival time = previous arrival + inter-arrival
 *  3. Generate service time using expRandom(mu)
 *  4. Start time = MAX(arrival time, previous end time)  ← the key M/M/1 rule
 *  5. End time = start + service
 *  6. Wait = start - arrival
 *  7. Turnaround = end - arrival
 *  8. Response = service time
 */
export function simulateMM1(input: SimInput): SimResults {
  const { lambda, mu, n } = input;
  const rows: CustomerRow[] = [];
  let prevEnd = 0;
  let prevArrival = 0;

  for (let i = 1; i <= n; i++) {
    const interArrival   = i === 1 ? 0 : round2(expRandom(lambda));
    const arrivalTime    = round2(i === 1 ? 0 : prevArrival + interArrival);
    const serviceTime    = round2(expRandom(mu));
    const startTime      = round2(Math.max(arrivalTime, prevEnd));
    const endTime        = round2(startTime + serviceTime);
    const waitTime       = round2(startTime - arrivalTime);
    const turnaroundTime = round2(endTime - arrivalTime);
    const responseTime   = round2(serviceTime); // response = pure service time

    rows.push({
      id: i,
      interArrival,
      arrivalTime,
      serviceTime,
      startTime,
      endTime,
      waitTime,
      turnaroundTime,
      responseTime,
    });

    prevEnd     = endTime;
    prevArrival = arrivalTime;
  }

  // ── Aggregate metrics ──
  const totalTime      = rows[rows.length - 1]?.endTime ?? 0;
  const safeN          = Math.max(n, 1);
  const avgInterArrival = round2(
    rows.slice(1).reduce((s, r) => s + r.interArrival, 0) / Math.max(n - 1, 1)
  );
  const avgWait        = round2(rows.reduce((s, r) => s + r.waitTime, 0) / safeN);
  const avgService     = round2(rows.reduce((s, r) => s + r.serviceTime, 0) / safeN);
  const avgTurnaround  = round2(rows.reduce((s, r) => s + r.turnaroundTime, 0) / safeN);
  const avgResponse    = round2(rows.reduce((s, r) => s + r.responseTime, 0) / safeN);
  const busyTime       = rows.reduce((s, r) => s + r.serviceTime, 0);
  const utilization    = round2((busyTime / Math.max(totalTime, 0.001)) * 100);

  return {
    customers: rows,
    avgInterArrival,
    avgWait,
    avgService,
    avgTurnaround,
    avgResponse,
    utilization,
    totalTime,
  };
}
