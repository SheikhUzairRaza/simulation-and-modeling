"use client";

// ─────────────────────────────────────────────────────────────────────────────
// MM1SimulationPanel.tsx
// Pure UI — no simulation logic here, all logic comes from useSimulation hook.
// Place this in: frontend/src/components/MM1SimulationPanel.tsx
// ─────────────────────────────────────────────────────────────────────────────

import { useState } from "react";
import { Activity, BarChart2, Clock3, Play, RotateCcw, Table2, Users, Zap } from "lucide-react";
import { useSimulation } from "@/hooks/useSimulation";
import { type CustomerRow, type SimResults } from "@/services/mm1Service";

// ─── Bar colors for Gantt ─────────────────────────────────────────────────────

const BAR_COLORS = [
  "#6366f1", "#0ea5e9", "#10b981", "#f59e0b",
  "#ec4899", "#8b5cf6", "#06b6d4", "#f97316",
  "#84cc16", "#e11d48",
];

// ─── Gantt Chart ──────────────────────────────────────────────────────────────

function GanttChart({
  customers,
  totalTime,
}: {
  customers: CustomerRow[];
  totalTime: number;
}) {
  const safeTotal = Math.max(totalTime, 0.001);
  const ticks     = Array.from({ length: 7 }, (_, i) =>
    Math.round((safeTotal / 6) * i * 100) / 100
  );
  const ROW_H    = 36;
  const LABEL_W  = 52;

  return (
    <div className="overflow-x-auto">
      <div className="min-w-[520px]">

        {/* Time axis tick labels */}
        <div className="flex" style={{ paddingLeft: LABEL_W }}>
          <div
            className="relative w-full text-[10px] text-[var(--muted)]"
            style={{ height: 16 }}
          >
            {ticks.map((t) => (
              <span
                key={t}
                className="absolute -translate-x-1/2 select-none whitespace-nowrap"
                style={{ left: `${(t / safeTotal) * 100}%` }}
              >
                {t}
              </span>
            ))}
          </div>
        </div>

        {/* Chart body */}
        <div
          className="relative"
          style={{ height: customers.length * ROW_H + 4 }}
        >
          {/* Vertical grid lines */}
          <div className="absolute inset-0" style={{ left: LABEL_W }}>
            {ticks.map((t) => (
              <div
                key={t}
                className="absolute top-0 h-full border-l border-dashed border-[var(--line)] opacity-30"
                style={{ left: `${(t / safeTotal) * 100}%` }}
              />
            ))}
          </div>

          {/* One row per customer */}
          {customers.map((c, idx) => {
            const color  = BAR_COLORS[idx % BAR_COLORS.length];
            const top    = idx * ROW_H + 2;
            const barH   = ROW_H - 10;

            const waitL  = (c.arrivalTime  / safeTotal) * 100;
            const waitW  = (c.waitTime     / safeTotal) * 100;
            const svcL   = (c.startTime    / safeTotal) * 100;
            const svcW   = (c.serviceTime  / safeTotal) * 100;

            return (
              <div
                key={c.id}
                className="absolute flex w-full items-center"
                style={{ top, height: barH }}
              >
                {/* Row label */}
                <div
                  className="shrink-0 pr-2 text-right text-[11px] font-bold text-[var(--muted)]"
                  style={{ width: LABEL_W }}
                >
                  C{c.id}
                </div>

                {/* Bar track */}
                <div
                  className="relative flex-1 rounded-sm bg-[var(--panel)]"
                  style={{ height: barH }}
                >
                  {/* Wait segment — striped dashed */}
                  {c.waitTime > 0.01 && (
                    <div
                      title={`C${c.id} waiting: ${c.waitTime} min`}
                      className="absolute top-0 h-full rounded-sm"
                      style={{
                        left:   `${waitL}%`,
                        width:  `${Math.max(waitW, 0.5)}%`,
                        background: `repeating-linear-gradient(
                          45deg,
                          ${color}44, ${color}44 3px,
                          transparent 3px, transparent 8px
                        )`,
                        border: `1.5px dashed ${color}`,
                      }}
                    />
                  )}

                  {/* Service segment — solid filled */}
                  <div
                    title={`C${c.id} service: ${c.serviceTime} min`}
                    className="absolute top-0 flex h-full items-center justify-center overflow-hidden rounded-sm text-[10px] font-bold text-white"
                    style={{
                      left:       `${svcL}%`,
                      width:      `${Math.max(svcW, 0.5)}%`,
                      background: color,
                      boxShadow:  `0 1px 8px ${color}66`,
                    }}
                  >
                    {svcW > 5 ? `C${c.id}` : ""}
                  </div>
                </div>
              </div>
            );
          })}
        </div>

        {/* Legend */}
        <div className="mt-3 flex flex-wrap gap-5 text-xs text-[var(--muted)]">
          <div className="flex items-center gap-2">
            <div
              className="h-3 w-8 rounded-sm"
              style={{
                background: `repeating-linear-gradient(
                  45deg,#6366f144,#6366f144 3px,transparent 3px,transparent 8px
                )`,
                border: "1.5px dashed #6366f1",
              }}
            />
            <span>Waiting in queue</span>
          </div>
          <div className="flex items-center gap-2">
            <div className="h-3 w-8 rounded-sm bg-[#6366f1]" />
            <span>Being served</span>
          </div>
        </div>
      </div>
    </div>
  );
}

// ─── Simulation Table ─────────────────────────────────────────────────────────

function SimulationTable({ results }: { results: SimResults }) {
  const headers = [
    "C#", "Inter-Arr", "Arrival", "Service",
    "Start", "End", "Wait", "Turnaround", "Response",
  ];

  return (
    <div className="overflow-x-auto">
      <table className="min-w-full border-separate border-spacing-y-1 text-sm">
        <thead>
          <tr className="text-left text-[10px] uppercase tracking-wider text-[var(--muted)]">
            {headers.map((h) => (
              <th key={h} className="px-2 py-2">{h}</th>
            ))}
          </tr>
        </thead>
        <tbody>
          {results.customers.map((c) => (
            <tr key={c.id} className="result-stat">
              <td
                className="px-2 py-2 font-bold"
                style={{ color: BAR_COLORS[(c.id - 1) % BAR_COLORS.length] }}
              >
                C{c.id}
              </td>
              <td className="px-2 py-2">{c.interArrival}</td>
              <td className="px-2 py-2">{c.arrivalTime}</td>
              <td className="px-2 py-2">{c.serviceTime}</td>
              <td className="px-2 py-2">{c.startTime}</td>
              <td className="px-2 py-2">{c.endTime}</td>
              <td
                className="px-2 py-2 font-semibold"
                style={{ color: c.waitTime > 0 ? "var(--danger)" : "var(--success)" }}
              >
                {c.waitTime}
              </td>
              <td className="px-2 py-2">{c.turnaroundTime}</td>
              <td className="px-2 py-2">{c.responseTime}</td>
            </tr>
          ))}

          {/* Averages row */}
          <tr className="font-bold text-[var(--accent)]">
            <td className="px-2 py-3 text-[10px] uppercase" colSpan={1}>Avg</td>
            <td className="px-2 py-3">{results.avgInterArrival}</td>
            <td className="px-2 py-3">—</td>
            <td className="px-2 py-3">{results.avgService}</td>
            <td className="px-2 py-3">—</td>
            <td className="px-2 py-3">—</td>
            <td className="px-2 py-3">{results.avgWait}</td>
            <td className="px-2 py-3">{results.avgTurnaround}</td>
            <td className="px-2 py-3">{results.avgResponse}</td>
          </tr>
        </tbody>
      </table>
    </div>
  );
}

// ─── Main Panel ───────────────────────────────────────────────────────────────

export default function MM1SimulationPanel() {
  const {
    lambda, mu, customers,
    setLambda, setMu, setCustomers,
    results, error,
    run, reset,
  } = useSimulation();

  const [view, setView] = useState<"gantt" | "table">("gantt");

  return (
    <div className="grid gap-5 xl:grid-cols-[0.85fr_1.15fr]">

      {/* ── Left: Input panel ── */}
      <section className="space-y-5">
        <div className="shell-card rise-in p-5 sm:p-6">
          <div className="flex items-start justify-between gap-3">
            <div>
              <p className="kicker text-[var(--accent)]">M/M/1 Engine</p>
              <h2 className="title-main mt-2 text-2xl">Queue Simulation</h2>
              <p className="muted mt-2 text-sm">
                Single-server Poisson arrivals with exponential service times.
                Random variates generated via inverse transform method.
              </p>
            </div>
            <div className="rounded-2xl border-2 border-[var(--line)] bg-[var(--panel)] p-3">
              <Zap className="h-6 w-6 text-[var(--accent-alt)]" />
            </div>
          </div>

          <div className="mt-6 space-y-4">

            {/* Lambda input */}
            <div className="space-y-1">
              <label className="kicker muted text-xs">
                Arrival Rate λ (customers / min)
              </label>
              <input
                type="number" step="0.01" min="0.01" value={lambda}
                onChange={(e) => setLambda(e.target.value)}
                className={`w-full rounded-xl border-2 bg-[var(--panel)] px-4 py-3 text-sm font-semibold text-[var(--fg)] outline-none transition-colors focus:border-[var(--accent)] ${
                  error?.field === "lambda" ? "border-[var(--danger)]" : "border-[var(--line)]"
                }`}
                placeholder="e.g. 0.5"
              />
            </div>

            {/* Mu input */}
            <div className="space-y-1">
              <label className="kicker muted text-xs">
                Service Rate μ (customers / min)
              </label>
              <input
                type="number" step="0.01" min="0.01" value={mu}
                onChange={(e) => setMu(e.target.value)}
                className={`w-full rounded-xl border-2 bg-[var(--panel)] px-4 py-3 text-sm font-semibold text-[var(--fg)] outline-none transition-colors focus:border-[var(--accent)] ${
                  error?.field === "mu" ? "border-[var(--danger)]" : "border-[var(--line)]"
                }`}
                placeholder="e.g. 0.8"
              />
            </div>

            {/* Customers input */}
            <div className="space-y-1">
              <label className="kicker muted text-xs">
                Number of Customers (2–30)
              </label>
              <input
                type="number" step="1" min="2" max="30" value={customers}
                onChange={(e) => setCustomers(e.target.value)}
                className={`w-full rounded-xl border-2 bg-[var(--panel)] px-4 py-3 text-sm font-semibold text-[var(--fg)] outline-none transition-colors focus:border-[var(--accent)] ${
                  error?.field === "n" ? "border-[var(--danger)]" : "border-[var(--line)]"
                }`}
                placeholder="e.g. 8"
              />
            </div>

            {/* Error message */}
            {error && (
              <p className="rounded-xl border-2 border-[var(--danger)] bg-[var(--panel)] px-4 py-3 text-sm text-[var(--danger)]">
                {error.message}
              </p>
            )}

            {/* Action buttons */}
            <div className="flex gap-3 pt-1">
              <button
                type="button" onClick={run}
                className="btn-main inline-flex flex-1 items-center justify-center gap-2"
              >
                <Play className="h-5 w-5" />
                <span>Run Simulation</span>
              </button>

              {results && (
                <button
                  type="button" onClick={reset}
                  className="inline-flex items-center justify-center gap-2 rounded-xl border-2 border-[var(--line)] bg-[var(--panel)] px-4 py-3 text-sm font-semibold text-[var(--muted)] transition-colors hover:border-[var(--accent)] hover:text-[var(--fg)]"
                >
                  <RotateCcw className="h-4 w-4" />
                </button>
              )}
            </div>
          </div>
        </div>

        {/* Formula reference card */}
        <div className="shell-card rise-in p-5 sm:p-6">
          <div className="flex items-center gap-3">
            <Clock3 className="h-5 w-5 text-[var(--accent)]" />
            <h3 className="title-main text-lg">Formulas Used</h3>
          </div>
          <div className="mt-4 space-y-2 text-xs text-[var(--muted)]">
            <p>
              <span className="font-semibold text-[var(--fg)]">Inter-arrival / Service</span>
              {"  →  "}−(1/rate) × ln(U)
            </p>
            <p>
              <span className="font-semibold text-[var(--fg)]">Arrival Time</span>
              {"  →  "}prev arrival + inter-arrival
            </p>
            <p>
              <span className="font-semibold text-[var(--fg)]">Start Time</span>
              {"  →  "}MAX(arrival, prev end time)
            </p>
            <p>
              <span className="font-semibold text-[var(--fg)]">End Time</span>
              {"  →  "}start + service
            </p>
            <p>
              <span className="font-semibold text-[var(--fg)]">Wait Time</span>
              {"  →  "}start − arrival
            </p>
            <p>
              <span className="font-semibold text-[var(--fg)]">Turnaround</span>
              {"  →  "}end − arrival
            </p>
            <p>
              <span className="font-semibold text-[var(--fg)]">Utilization</span>
              {"  →  "}total service / total time × 100
            </p>
          </div>
        </div>
      </section>

      {/* ── Right: Results panel ── */}
      <section className="space-y-5">

        {/* Empty state */}
        {!results ? (
          <div className="shell-card rise-in flex min-h-[320px] flex-col items-center justify-center gap-4 p-8 text-center">
            <div className="rounded-2xl border-2 border-[var(--line)] bg-[var(--panel)] p-5">
              <BarChart2 className="h-10 w-10 text-[var(--muted)]" />
            </div>
            <p className="kicker muted">No simulation yet</p>
            <p className="muted max-w-xs text-sm">
              Enter λ, μ and customer count on the left, then press Run Simulation.
            </p>
          </div>
        ) : (
          <>
            {/* Performance metrics */}
            <div className="shell-card rise-in p-5 sm:p-6">
              <div className="flex flex-wrap items-start justify-between gap-3">
                <div>
                  <p className="kicker text-[var(--accent-alt)]">Simulation Output</p>
                  <h2 className="title-main mt-2 text-2xl">Performance Measures</h2>
                  <p className="muted mt-1 text-sm">
                    {results.customers.length} customers · total time {results.totalTime} min
                  </p>
                </div>
                <div className="label-chip">
                  <span className="status-live blink-soft" />
                  Simulated
                </div>
              </div>

              <div className="mt-5 grid grid-cols-2 gap-3 sm:grid-cols-3">
                <div className="metric-tile">
                  <p className="kicker muted">Avg Inter-Arrival</p>
                  <p className="metric-value text-[var(--accent)]">{results.avgInterArrival} min</p>
                </div>
                <div className="metric-tile">
                  <p className="kicker muted">Avg Service Time</p>
                  <p className="metric-value text-[var(--accent-alt)]">{results.avgService} min</p>
                </div>
                <div className="metric-tile">
                  <p className="kicker muted">Avg Wait Time</p>
                  <p className="metric-value text-[var(--danger)]">{results.avgWait} min</p>
                </div>
                <div className="metric-tile">
                  <p className="kicker muted">Avg Turnaround</p>
                  <p className="metric-value text-[var(--success)]">{results.avgTurnaround} min</p>
                </div>
                <div className="metric-tile">
                  <p className="kicker muted">Avg Response</p>
                  <p className="metric-value text-[var(--accent)]">{results.avgResponse} min</p>
                </div>
                <div className="metric-tile">
                  <p className="kicker muted">Server Utilization</p>
                  <p
                    className="metric-value"
                    style={{
                      color:
                        results.utilization > 90 ? "var(--danger)"
                        : results.utilization > 70 ? "#f59e0b"
                        : "var(--success)",
                    }}
                  >
                    {results.utilization}%
                  </p>
                </div>
              </div>
            </div>

            {/* Gantt + Table toggle */}
            <div className="shell-card rise-in p-5 sm:p-6">
              <div className="flex flex-wrap items-center justify-between gap-3">
                <div className="flex items-center gap-3">
                  {view === "gantt"
                    ? <BarChart2 className="h-5 w-5 text-[var(--accent)]" />
                    : <Table2   className="h-5 w-5 text-[var(--accent)]" />}
                  <h3 className="title-main text-xl">
                    {view === "gantt" ? "Gantt Chart" : "Simulation Table"}
                  </h3>
                </div>

                {/* View toggle pills */}
                <div className="flex rounded-xl border-2 border-[var(--line)] bg-[var(--panel)] p-1 text-sm">
                  {(["gantt", "table"] as const).map((v) => (
                    <button
                      key={v} type="button" onClick={() => setView(v)}
                      className={`rounded-lg px-4 py-1.5 font-semibold capitalize transition-all ${
                        view === v
                          ? "bg-[var(--accent)] text-white shadow"
                          : "text-[var(--muted)] hover:text-[var(--fg)]"
                      }`}
                    >
                      {v}
                    </button>
                  ))}
                </div>
              </div>

              <div className="mt-5">
                {view === "gantt" ? (
                  <GanttChart
                    customers={results.customers}
                    totalTime={results.totalTime}
                  />
                ) : (
                  <SimulationTable results={results} />
                )}
              </div>
            </div>

            {/* Insight cards */}
            <div className="grid gap-4 md:grid-cols-3">
              <div className="shell-card rise-in p-5">
                <div className="flex items-center gap-2">
                  <Activity className="h-5 w-5 text-[var(--accent-alt)]" />
                  <p className="title-main text-lg">Queue Health</p>
                </div>
                <p className="muted mt-3 text-sm">
                  {results.utilization < 70
                    ? "Server handles demand comfortably with spare capacity."
                    : results.utilization < 90
                    ? "Moderate load — queue may build at busy intervals."
                    : "Heavy load — long waits expected to accumulate."}
                </p>
              </div>

              <div className="shell-card rise-in p-5">
                <div className="flex items-center gap-2">
                  <Users className="h-5 w-5 text-[var(--success)]" />
                  <p className="title-main text-lg">Wait Signal</p>
                </div>
                <p className="muted mt-3 text-sm">
                  Average customer waited{" "}
                  <span className="font-semibold text-[var(--fg)]">{results.avgWait} min</span>{" "}
                  before being served in this run.
                </p>
              </div>

              <div className="shell-card rise-in p-5">
                <div className="flex items-center gap-2">
                  <Clock3 className="h-5 w-5 text-[var(--accent)]" />
                  <p className="title-main text-lg">Throughput</p>
                </div>
                <p className="muted mt-3 text-sm">
                  {results.customers.length} customers processed in{" "}
                  <span className="font-semibold text-[var(--fg)]">{results.totalTime} min</span>{" "}
                  total simulation time.
                </p>
              </div>
            </div>
          </>
        )}
      </section>
    </div>
  );
}
