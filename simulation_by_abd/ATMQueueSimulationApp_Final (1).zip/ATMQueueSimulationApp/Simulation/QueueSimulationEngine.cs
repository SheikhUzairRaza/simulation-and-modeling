using System;
using System.Collections.Generic;
using System.Linq;
using ATMQueueSimulationApp.Models;
using ATMQueueSimulationApp.Services;

namespace ATMQueueSimulationApp.Simulation
{
    /// <summary>
    /// The one and only simulation engine. Every one of the 6 queueing models (M/M/1, M/M/s,
    /// M/G/1, M/G/s, G/G/1, G/G/s) runs through this exact same code - the only thing that
    /// changes between them is which IDistribution objects and how many servers
    /// QueueModelFactory hands it in the SimulationParameters. This is how the project meets
    /// the "reuse common logic instead of duplicating code" requirement.
    ///
    /// Algorithm (standard FCFS, single shared queue, s identical servers):
    ///   For each customer, in arrival order:
    ///     - find the server that becomes free soonest
    ///     - the customer starts service at max(arrival time, that server's free time)
    ///     - the server's free time becomes (start + service time)
    /// </summary>
    public class QueueSimulationEngine
    {
        public SimulationResult Run(SimulationParameters parameters)
        {
            // Stability check first, before generating a single customer. This covers every
            // input mode (custom rates, default dataset, random dataset) because
            // QueueModelFactory always resolves ArrivalDistribution.Mean / ServiceDistribution.Mean
            // the same way regardless of where lambda/mu came from.
            double rho = StabilityChecker.CalculateUtilization(parameters);
            if (!StabilityChecker.IsStable(rho))
            {
                return BuildUnstableResult(parameters, rho);
            }

            var rng = new Random(parameters.RandomSeed);

            List<Customer> customers = parameters.UseDefaultDataset && parameters.DatasetCustomers is not null
                ? BuildCustomersFromDataset(parameters, rng)
                : GenerateCustomers(parameters, rng);

            var serverIntervals = SimulateService(customers, parameters.NumServers);

            var result = StatisticsCalculator.Calculate(
                customers,
                serverIntervals,
                parameters.NumServers,
                parameters.ModelDisplayName);

            result.IsStable = true;
            result.Rho = rho;
            return result;
        }

        /// <summary>
        /// Built instead of actually simulating when rho >= 1. No customers are generated, no
        /// charts are drawn, and no KPIs are calculated - they would not be meaningful for an
        /// unstable system. The warning message is carried in LogLines so the caller can show
        /// it both in a MessageBox and in the Simulation Log from the same source of truth.
        /// </summary>
        private static SimulationResult BuildUnstableResult(SimulationParameters parameters, double rho)
        {
            string warning = StabilityChecker.BuildWarningMessage(rho);

            return new SimulationResult
            {
                ModelName = parameters.ModelDisplayName,
                NumServers = parameters.NumServers,
                IsStable = false,
                Rho = rho,
                CustomersServed = 0,
                LogLines = new List<string>(warning.Split('\n'))
            };
        }

        /// <summary>
        /// Custom-parameter mode: event-driven arrival generation. Customers are generated
        /// one at a time from the arrival distribution until the next arrival would fall
        /// after SimulationTimeMinutes - at that point generation stops. The total number
        /// of customers is therefore a calculated outcome of (arrival rate x simulation time),
        /// not a user-supplied count.
        /// </summary>
        private static List<Customer> GenerateCustomers(SimulationParameters parameters, Random rng)
        {
            var customers = new List<Customer>();
            double clock = 0.0;
            int id = 1;

            while (true)
            {
                double gap = parameters.ArrivalDistribution.Sample(rng);
                double nextArrival = clock + gap;

                // Stop generating once the next arrival would occur after the simulation
                // window ends - customers who have already arrived are still fully served.
                if (nextArrival > parameters.SimulationTimeMinutes)
                    break;

                clock = nextArrival;

                customers.Add(new Customer
                {
                    CustomerId = id,
                    ArrivalTime = clock,
                    InterarrivalTime = gap,
                    ServiceTime = parameters.ServiceDistribution.Sample(rng),
                    TransactionType = "Simulated"
                });

                id++;
            }

            return customers;
        }

        /// <summary>
        /// Default-dataset mode: reuse the real HBL ATM records for realism (transaction types,
        /// overall pattern), but regenerate arrival gaps / service times through the model's own
        /// distributions where the model calls for a Markovian (M) process, or reuse the actual
        /// recorded value where the model calls for a General (G) process. The full dataset is
        /// always simulated - there is no customer-count or simulation-time limit in this mode.
        /// </summary>
        private static List<Customer> BuildCustomersFromDataset(SimulationParameters parameters, Random rng)
        {
            var source = parameters.DatasetCustomers!;

            var customers = new List<Customer>();
            double clock = 0.0;

            for (int i = 0; i < source.Count; i++)
            {
                var src = source[i];

                double gap = parameters.ArrivalIsMarkovian
                    ? parameters.ArrivalDistribution.Sample(rng)
                    : src.InterarrivalTime;

                clock += gap;

                double serviceTime = parameters.ServiceIsMarkovian
                    ? parameters.ServiceDistribution.Sample(rng)
                    : src.ServiceTime;

                customers.Add(new Customer
                {
                    CustomerId = i + 1,
                    ArrivalTime = clock,
                    InterarrivalTime = gap,
                    ServiceTime = Math.Max(0.05, serviceTime),
                    TransactionType = src.TransactionType
                });
            }

            return customers;
        }

        /// <summary>Assigns each customer (already sorted by arrival time) to the earliest-available server.</summary>
        private static List<ServerInterval> SimulateService(List<Customer> customers, int numServers)
        {
            numServers = Math.Max(1, numServers);
            var serverFreeAt = new double[numServers];
            var intervals = new List<ServerInterval>(customers.Count);

            foreach (var customer in customers)
            {
                int serverIndex = 0;
                double earliestFree = serverFreeAt[0];
                for (int s = 1; s < numServers; s++)
                {
                    if (serverFreeAt[s] < earliestFree)
                    {
                        earliestFree = serverFreeAt[s];
                        serverIndex = s;
                    }
                }

                double start = Math.Max(customer.ArrivalTime, serverFreeAt[serverIndex]);
                double end = start + customer.ServiceTime;

                customer.ServiceStartTime = start;
                customer.ServiceEndTime = end;
                customer.ServerIndex = serverIndex;

                serverFreeAt[serverIndex] = end;

                intervals.Add(new ServerInterval
                {
                    ServerIndex = serverIndex,
                    CustomerId = customer.CustomerId,
                    Start = start,
                    End = end,
                    TransactionType = customer.TransactionType
                });
            }

            return intervals;
        }
    }
}
