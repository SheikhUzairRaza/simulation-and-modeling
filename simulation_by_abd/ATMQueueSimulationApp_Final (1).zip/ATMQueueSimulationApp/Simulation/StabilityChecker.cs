namespace ATMQueueSimulationApp.Simulation
{
    /// <summary>
    /// Checks whether a queueing system is stable before it is simulated.
    ///
    /// Queueing theory requires rho = lambda / (s * mu) &lt; 1 for a queue to reach steady
    /// state. If rho >= 1, arrivals occur faster than the servers can clear them, so the
    /// queue grows without bound and any "results" the engine would produce (waiting time,
    /// queue length, utilization, ...) are not meaningful - they just reflect the finite
    /// simulation window, not real system behaviour.
    ///
    /// lambda and mu are both taken from SimulationParameters.ArrivalDistribution.Mean /
    /// ServiceDistribution.Mean, which QueueModelFactory always populates the same way
    /// regardless of source (typed-in custom rate, or estimated from the default/random
    /// dataset) - so this one check covers every input mode without special-casing any of them.
    /// </summary>
    public static class StabilityChecker
    {
        /// <summary>rho = lambda / (s * mu), using the arrival/service means already resolved onto the model.</summary>
        public static double CalculateUtilization(SimulationParameters parameters)
        {
            double lambda = 1.0 / parameters.ArrivalDistribution.Mean;   // customers/min
            double mu = 1.0 / parameters.ServiceDistribution.Mean;       // customers/min per server
            int servers = parameters.NumServers > 0 ? parameters.NumServers : 1;

            return lambda / (servers * mu);
        }

        /// <summary>A stable queueing system requires rho &lt; 1.</summary>
        public static bool IsStable(double rho) => rho < 1.0;

        /// <summary>
        /// The exact warning text shown to the user - used for both the MessageBox popup
        /// and the Simulation Log, so the two never drift out of sync.
        /// </summary>
        public static string BuildWarningMessage(double rho)
        {
            return
                "\u26A0 Simulation cannot be executed.\n" +
                "The queueing system is unstable.\n\n" +
                "Reason:\n" +
                "Arrival Rate (\u03BB) is greater than or equal to the system service capacity.\n\n" +
                $"Current Utilization (\u03C1) = {rho:0.00}\n\n" +
                "For a stable queueing system:\n" +
                "\u03C1 must be less than 1.\n\n" +
                "Please increase the service rate, decrease the arrival rate, or increase the number of servers.";
        }
    }
}
